#########################R script to CCA analysis###################################

install.packages("devtools")
install.packages("rlang")
devtools::install_github("gavinsimpson/ggvegan")
install.packages("gridExtra")

library(vegan)
library(MASS)
library(rlang)
library(ggvegan)
library(ggplot2)
library(ggrepel)
library(gridExtra)
library(ggpubr)
library(grDevices)

env.ut <- read.csv("utFQH.csv", row.names=1, header = T, sep=",")

#Table prune regarding to variables that presente higher values of variation inflated factor > 10
env.utc3 <- env.ut[,-c(3,4,5,6,11,14:17)]

###Composition UTRs in feb+apr14, july+sept14, nov14+feb2015
utr.sum <- read.csv("utr_sum.csv", header = T, sep=",") 
rownames(utr.sum) <- rownames(env.ut)

##########################cca############################################

cca4.3 <- cca(utr.sum, env.utc3)
vif.cca(cca4.3)
alias(cca4.3)

gn <- fortify(cca4.3, display = "sp")
site <- fortify(cca4.3, display = "sites")

Zone <- c(rep("Ref1", 3), rep("Min", 3), rep("CP", 3), rep("Agr", 3), rep("Ref2", 3))

##########################Mosaic of CCA plot###############################

p.cca4.3g <- autoplot(cca4.3, layers = "biplot", legend = "none")

vall <- cca4.3$CCA$biplot
v <- vall[,c(1:2)] 
dfv <- data.frame(v)

data.scores <- site[,c(3:4)]
data.scores$site <- site$Label
data.scores$Zone <- Zone
hull.data <- data.scores 

hull.data$Zone <- factor(data.scores$Zone, levels = c("Ref1", "Ref2", "Agr", "CP", "Min")) ###To order the legend of Sampling Zone.

ggplot()+
  geom_text_repel(data = gn, size = 2.8, mapping = aes(x = CCA1, y = CCA2, label = Label), family = "Times", fontface="italic", colour = "darkgrey")+
  geom_text_repel(data = site, size = 2, mapping = aes(x = CCA1, y = CCA2, label = Label), family = "Times", colour = "black")+
  geom_point(data=hull.data,aes(x = CCA1, y = CCA2,shape=Zone),size=3)+
  geom_segment(dfv, mapping = aes(x=0, xend=CCA1, y=0, yend=CCA2), color="black", arrow=arrow(length=unit(0.01,"npc")))+ 
  geom_text(dfv, mapping = aes(x=CCA1, y=CCA2, label = rownames(dfv), hjust=0.5*(1-sign(CCA1)), vjust=0.5*(1-sign(CCA2))), color="black", size=4)+
  geom_polygon(data=hull.data,aes(x=CCA1,y=CCA2, fill=Zone),alpha=0.30)+
  theme_classic()+
  geom_vline(xintercept=0, color = "grey", lty = 2)+
  geom_hline(yintercept=0, color = "grey", lty = 2)+
  theme(legend.position = c(0.90, 0.15))+
  xlab("CCA1 (42.2%)")+
  ylab("CCA2 (21.1%)")+
  theme(text=element_text(size=14, family = "TT Times New Roman"))+
  theme(legend.text = element_text(colour = "black", size = 12, family = "TT Times New Roman"))+
  theme(panel.background=element_rect(fill='transparent',color='black',size=1))

ggsave("fig4.tiff", width = 10, height = 8, units = "in", dpi = 300)

