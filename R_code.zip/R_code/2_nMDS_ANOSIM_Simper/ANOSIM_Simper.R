rm(list=ls())

install.packages("vegan")
library(vegan)

##################datos abejas - sirphidae##########################

esc3 <- read.table("esc3.txt", header = T)
Zona <- rownames(esc3) 

g.ndms <- cbind(Zona, esc3)
rownames(g.ndms) <- seq(1,15,1)

data1 <- g.ndms[,-1] 
#data2 <- g.ndms[,1]

data2 <- c(rep("Ref1", 3), rep("Mi", 3), rep("CP", 3), rep("Agr", 3), rep("Ref2", 3))
df <- data.frame(data2); 
colnames(df) <- "Zona"

Com.dist <- vegdist(data1)

ano <- anosim(Com.dist, data2)
plot(ano)

sim <- with(df, simper(data1, Zona))
summary(sim)
