m(list=ls())

install.packages("ggrepel")
install.packages("vegan")

library(MASS)
library(vegan)
library(ggplot2)
library(ggrepel)

#################################Input data##################################

ti=read.table("esc3.txt", header = T) #Data of UTRs grouping per sampling pair-month  
#ti <- read.csv("nmds_g.csv", header = T)#Data of UTRs per sampling month

rnames <- c(paste(rep("Ref1",3),seq(1,3,1), sep="_"),
            paste(rep("Min",3),seq(1,3,1), sep="_"),
            paste(rep("CP",3),seq(1,3,1), sep="_"),
            paste(rep("Agr",3),seq(1,3,1), sep="_"),
            paste(rep("Ref2",3),seq(1,3,1), sep="_"))
rownames(ti) <- rnames  

Zone <- c(rep("Ref1", 3), rep("Min", 3), rep("CP", 3), rep("Agr", 3), rep("Ref2", 3))

Zone <- factor(Zone, levels = c("Ref1", "Ref2", "Agr", "CP", "Min"))

####nMDS####

data_nMDS = metaMDS(ti, distance = "bray", trymax = 3, autotransform = F)
data_nMDS

##################Data prepared to nMDS plot, Figure 3#############################
data.scores <- as.data.frame(scores(data_nMDS))
data.scores$site <- rownames(data.scores)
data.scores$Zone <- Zone
head(data.scores)

gr.Ref1 <- data.scores[data.scores$Zone == "Ref1", ][chull(data.scores[data.scores$Zone == "Ref1", c("NMDS1", "NMDS2")]), ] 

gr.Min <- data.scores[data.scores$Zone == "Min", ][chull(data.scores[data.scores$Zone == "Min", c("NMDS1", "NMDS2")]), ] 

gr.CP <- data.scores[data.scores$Zone == "CP", ][chull(data.scores[data.scores$Zone == "CP", c("NMDS1", "NMDS2")]), ] 

gr.Agr <- data.scores[data.scores$Zone == "Agr", ][chull(data.scores[data.scores$Zone == "Agr", c("NMDS1", "NMDS2")]), ] 

gr.Ref2 <- data.scores[data.scores$Zone == "Ref2", ][chull(data.scores[data.scores$Zone == "Ref2", c("NMDS1", "NMDS2")]), ] 

hull.data <- rbind(gr.Ref1, gr.Min, gr.CP, gr.Agr, gr.Ref2)

species.scores <- as.data.frame(scores(data_nMDS, "species"))
species.scores$species <- rownames(species.scores)

head(species.scores)
legend_title <- "Zone"
data.scores$Zonenames <- rownames(data.scores)

ggplot() +
  geom_text_repel(data = species.scores, size = 2.8, mapping = aes(x=NMDS1,y=NMDS2,label=species), family = "Times", fontface="italic", colour = "darkgrey")+
  geom_text_repel(data = data.scores, family = "Times", size = 2.5, mapping = aes(x=NMDS1,y=NMDS2, label=Zonenames))+
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,shape=Zone),size=3)+
  geom_polygon(data=hull.data,aes(x=NMDS1,y=NMDS2, fill=Zone),alpha=0.30)+
  theme_classic()+
  geom_vline(xintercept=0, color = "grey", lty = 2)+
  geom_hline(yintercept=0, color = "grey", lty = 2)+
  theme(legend.position = c(0.90, 0.15))+
  theme(text=element_text(size=14, family = "TT Times New Roman"))+
  theme(legend.text = element_text(colour = "black", size = 12, family = "TT Times New Roman"))+
  theme(panel.background=element_rect(fill='transparent',color='black',size=1))

ggsave("fig3.tiff", width = 10, height = 8, units = "in", dpi = 300)
