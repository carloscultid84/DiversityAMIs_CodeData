####Data and R Code to diversity estimation of AMIs in effective number of species, Hill Series#################################################################################################################################DIVERSITY AND DENSITY OF MACROINVERTEBRATES IN COLOMBIAN ANDEAN STREAMS IMPACTED BY MINING, AGRICULTURE AND CATTLE PRODUCTION#########################################################################################

###############################################Packages######################################################

install.packages("iNEXT")

## or install the latest version from github
install.packages('devtools')
library(devtools)
install_github('JohnsonHsieh/iNEXT')
install.packages("ggpubr")

install.packages("coin")
install.packages("gvlma")
install.packages("survival")
install.packages("sandwich")

#Then

library(iNEXT)
library(ggplot2)
library(ggpubr)
library(reshape2)

library(coin)
library(survival)
library(sandwich)
library(gvlma)

###########################################Data input######################################################

dm <- read.csv("dmgenus.csv", header = T); dmg <- dm[,-1]

###########################################qD estimations##################################################

di <- DataInfo(dmg)###tabla resumen
ep <- round(max(di$n))
out=iNEXT(dmg, q=c(0, 1, 2),  datatype="abundance", endpoint=ep, knots = 120, nboot = 100)

#######################################Density analysis####################################################

source("http://www.r-statistics.com/wp-content/uploads/2010/02/Friedman-Test-with-Post-Hoc.r.txt")
 #or
source("subrutine_friedman.R")

Pert=read.table("Friedman.txt", header = T)
sum(Pert$Abundancia)
Pert$Dens <- (Pert$Abundancia/0.81)

dg <- read.csv("dt.csv", header = T) 
E <- rep(c(1:6), 5)
dg$E <- E

order=as.factor(rep(c(1, 5, 4, 3, 2), each=6))
zonas<-cbind(Pert,order)
levels(zonas$order)=c("Ref1","Ref2","Agr","CP","Mi")

friedman.test.with.post.hoc(Den  ~ Zone | E ,dg)

#############################DPlot 2A Density#########################

dt <- read.csv("dmias2.csv", header = T)
dt$Den <- round((dt$Abundance/0.81),1) 

dt$Zone <- factor(dt$Zone, levels = c("Ref1", "Ref2", "Agr", "CP", "Min")) 

f2A <- ggplot(dt, aes(x=Zone, y=Den)) + 
  geom_boxplot()+
  theme_classic()+
  xlab("")+
  ylab("Density")+
  theme(text=element_text(size=14, family = "TT Times New Roman"))+
  theme(panel.background=element_rect(fill='transparent',color='black',size=1))+
  annotate("text", x=1, y=450, label= "a") + 
  annotate("text", x=2, y=870, label = "b,a") +
  annotate("text", x=3, y=290, label= "c,a") + 
  annotate("text", x=4, y=430, label = "a") +
  annotate("text", x=5, y=570, label = "a")

###########################################Plot 2B qD##################################################

tplot <- read.csv("tplot2.csv", header = T, sep=",")

tplot$range <- tplot$Value - tplot$Li  
tplot$Zone <- factor(tplot$Zone, levels = c("Ref1", "Ref2", "Agr", "CP", "Min")) 

pd <- position_dodge(0.1) 

tp <- ggplot(tplot, aes(x = Zone, y = Value, shape = factor(qD), group = qD))+
  geom_errorbar(aes(ymin=Value-range, ymax=Value+range), width =.1, colour="black")+
  geom_point(size = 2)+
  geom_line(lty = 2, size = 0.2)+
  theme_classic()+
  xlab("Sampling zone")+
  ylab("Effective number of genus")+
  theme(text=element_text(size=14, family = "TT Times New Roman"))+
  theme(panel.background=element_rect(fill="transparent",color='black',size=1))

q0 <- expression(" "^0*"D")
q1 <- expression(" "^1*"D")
q2 <- expression(" "^2*"D")

f2B <- tp + theme(legend.position = c(0.9, 0.885))+
  theme(legend.title = element_blank())+
  scale_shape_discrete(label = c(q0, q1, q2))+
  theme(legend.text = element_text(colour = "black", size = 12, family = "TT Times New Roman"))+
  guides(shape = guide_legend(override.aes = list(size = 4)))

###Final Fig2 (A and B)####

ggarrange(f2A, f2B,
          labels = c("A", "B"),
          ncol = 1, nrow = 2)

ggsave("fig2ge.eps", width = 5, height = 10, units = "in", dpi = 300)
